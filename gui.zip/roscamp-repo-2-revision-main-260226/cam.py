import argparse
import cv2


def run_camera(device_index: int, width: int, height: int, window_name: str) -> None:
    cap = cv2.VideoCapture(device_index)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open camera device: {device_index}")

    if width > 0:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    if height > 0:
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)

    while True:
        ok, frame = cap.read()
        if not ok:
            print("Failed to read frame from camera.")
            break

        cv2.imshow(window_name, frame)
        key = cv2.waitKey(1) & 0xFF
        if key in (27, ord("q")):  # ESC or q
            break

    cap.release()
    cv2.destroyAllWindows()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Simple webcam preview window")
    parser.add_argument("--device", type=int, default=0, help="Camera device index")
    parser.add_argument("--width", type=int, default=0, help="Capture width (0 = default)")
    parser.add_argument("--height", type=int, default=0, help="Capture height (0 = default)")
    parser.add_argument("--title", default="Webcam Preview", help="OpenCV window title")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_camera(
        device_index=args.device,
        width=args.width,
        height=args.height,
        window_name=args.title,
    )
